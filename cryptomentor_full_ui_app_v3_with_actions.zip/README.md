
# Cryptomentor UI — Phone-only APK Build
1) Upload this folder to a new **GitHub** repo.
2) Open **Actions → Android Debug APK (Cryptomentor) → Run workflow**.
3) After it finishes, download **Artifacts → app-debug** → `app-debug.apk`.
4) Install the APK on your Android phone (Allow from unknown sources).

The workflow auto-sets the app name to **Cryptomentor**.
