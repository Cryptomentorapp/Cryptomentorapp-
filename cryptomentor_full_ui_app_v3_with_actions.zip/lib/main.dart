
import 'package:flutter/material.dart';
import 'ui/home_screen.dart';
import 'ui/signals_screen.dart';
import 'ui/scan_screen.dart';
import 'ui/alpha_screen.dart';
import 'ui/account_screen.dart';

void main() {
  runApp(const CryptomentorApp());
}

class CryptomentorApp extends StatelessWidget {
  const CryptomentorApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cryptomentor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFF2B705),
          secondary: Color(0xFF627EEA),
        ),
        scaffoldBackgroundColor: const Color(0xFF0E0F14),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF0F1117),
          indicatorColor: Color(0x33F2B705),
        ),
        fontFamily: 'Roboto',
      ),
      home: const RootNav(),
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> {
  int _index = 0;
  bool isPro = false;

  @override
  Widget build(BuildContext context) {
    final screens = [
      const HomeScreen(),
      SignalsScreen(isPro: isPro, onUpgrade: () => setState(() => isPro = true)),
      const ScanScreen(),
      const AlphaScreen(),
      const AccountScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: screens[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bolt), label: 'Signals'),
          NavigationDestination(icon: Icon(Icons.shield_moon_outlined), label: 'Scan'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Alpha'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Account'),
        ],
      ),
    );
  }
}
