
import 'dart:convert';
import 'package:flutter/material.dart';
import 'widgets/ai_hero_card.dart';
import 'widgets/market_list.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<dynamic> market = [];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadMarket();
  }

  Future<void> _loadMarket() async {
    final data = await DefaultAssetBundle.of(context).loadString('assets/data/market.json');
    setState(() => market = jsonDecode(data));
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                AIHeroCard(),
                SizedBox(height: 16),
              ],
            ),
          ),
        ),
        SliverAppBar(
          backgroundColor: const Color(0xFF0E0F14),
          pinned: true,
          automaticallyImplyLeading: false,
          title: const Text('Market'),
          bottom: TabBar(
            controller: _tab,
            isScrollable: true,
            tabs: const [
              Tab(text: 'Top Gainers'),
              Tab(text: 'Top Losers'),
              Tab(text: 'Trending'),
              Tab(text: 'Favorites'),
            ],
          ),
        ),
        SliverFillRemaining(
          hasScrollBody: true,
          child: TabBarView(
            controller: _tab,
            children: [
              MarketList(data: market, mode: MarketMode.gainers),
              MarketList(data: market, mode: MarketMode.losers),
              MarketList(data: market, mode: MarketMode.trending),
              MarketList(data: market, mode: MarketMode.favorites),
            ],
          ),
        ),
      ],
    );
  }
}
