
import 'dart:convert';
import 'package:flutter/material.dart';

class ScanScreen extends StatefulWidget { const ScanScreen({super.key}); @override State<ScanScreen> createState() => _ScanScreenState(); }
class _ScanScreenState extends State<ScanScreen> {
  List<dynamic> tokens = [];
  @override void didChangeDependencies(){ super.didChangeDependencies(); _load(); }
  Future<void> _load() async { final s = await DefaultAssetBundle.of(context).loadString('assets/data/scan.json'); setState(()=> tokens = jsonDecode(s)); }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Scan')),
      body: ListView.separated(
        padding: const EdgeInsets.all(12), itemCount: tokens.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) {
          final t = tokens[i] as Map<String, dynamic>;
          Color c = t['risk']=='High'? Colors.redAccent : t['risk']=='Medium'? Colors.orangeAccent : Colors.greenAccent;
          return ListTile(
            tileColor: const Color(0xFF11131A),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Color(0x2233CCFF))),
            title: Text(t['name']),
            subtitle: Text('Risk: ${t['risk']} • Contract: ${t['contract'][:6]}...'),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: c.withOpacity(0.15), border: Border.all(color: c.withOpacity(0.5)), borderRadius: BorderRadius.circular(12)),
              child: Text(t['risk'], style: TextStyle(color: c, fontWeight: FontWeight.w700)),
            ),
          );
        },
      ),
    );
  }
}
