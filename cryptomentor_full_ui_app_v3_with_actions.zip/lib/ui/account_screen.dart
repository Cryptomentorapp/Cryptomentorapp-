
import 'package:flutter/material.dart';

class AccountScreen extends StatelessWidget { const AccountScreen({super.key}); @override Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(title: const Text('Account')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        ListTile(leading: Icon(Icons.workspace_premium_outlined), title: Text('Subscription'), subtitle: Text('Pro (mock toggle in Signals'))),
        Divider(),
        ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings')),
        ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy')),
        ListTile(leading: Icon(Icons.info_outline), title: Text('About')),
      ],
    ),
  ); } }
