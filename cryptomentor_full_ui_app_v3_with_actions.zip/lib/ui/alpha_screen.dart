
import 'dart:convert';
import 'package:flutter/material.dart';

class AlphaScreen extends StatefulWidget { const AlphaScreen({super.key}); @override State<AlphaScreen> createState() => _AlphaScreenState(); }
class _AlphaScreenState extends State<AlphaScreen> {
  List<dynamic> briefs = [];
  @override void didChangeDependencies(){ super.didChangeDependencies(); _load(); }
  Future<void> _load() async { final s = await DefaultAssetBundle.of(context).loadString('assets/data/alpha.json'); setState(()=> briefs = jsonDecode(s)); }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hidden Alpha')),
      body: ListView.separated(
        padding: const EdgeInsets.all(12), itemCount: briefs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) {
          final b = briefs[i] as Map<String, dynamic>;
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFF11131A), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x2233CCFF))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b['title'], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text('Why: ${b['why']}'),
              Text('Risk: ${b['risk']}'),
              Text('Catalyst: ${b['catalyst']}'),
              Text('Valid: ${b['valid']}'),
            ]),
          );
        },
      ),
    );
  }
}
