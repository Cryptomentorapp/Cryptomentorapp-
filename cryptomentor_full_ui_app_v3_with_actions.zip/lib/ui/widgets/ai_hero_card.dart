
import 'package:flutter/material.dart';

class AIHeroCard extends StatelessWidget {
  const AIHeroCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF11131A),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: Color(0x3300FFFF), blurRadius: 24, spreadRadius: 1, offset: Offset(0, 6)),
        ],
        border: Border.all(color: const Color(0x2233CCFF)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
      child: Column(
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              _OrbLogo(),
              SizedBox(height: 8),
              Text(
                'AI Driven Trading',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.6,
                  color: Color(0xFFE6E8EC),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              _Feature(icon: Icons.insights_outlined, label: 'Real-time Insights'),
              _Feature(icon: Icons.shield_outlined, label: 'Enterprise Security'),
              _Feature(icon: Icons.bolt_outlined, label: 'Pro Signals'),
              _Feature(icon: Icons.track_changes_outlined, label: 'Smart Trading'),
            ],
          ),
        ],
      ),
    );
  }
}

class _OrbLogo extends StatelessWidget {
  const _OrbLogo();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      height: 120,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [Color(0xFF627EEA), Color(0xFF28304A), Color(0xFF0E0F14)],
          radius: 0.85,
          center: Alignment(0, -0.2),
        ),
      ),
      child: const Center(
        child: Text(
          'Cryptomentor',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.6,
          ),
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Feature({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0x191C90F3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x2233CCFF)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: const Color(0xFFA9C1FF)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
