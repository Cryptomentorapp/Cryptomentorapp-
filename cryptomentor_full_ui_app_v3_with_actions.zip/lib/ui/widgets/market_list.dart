
import 'package:flutter/material.dart';
import 'dart:math';

enum MarketMode { gainers, losers, trending, favorites }

class MarketList extends StatelessWidget {
  final List<dynamic> data;
  final MarketMode mode;
  const MarketList({super.key, required this.data, required this.mode});

  @override
  Widget build(BuildContext context) {
    if (data.isEmpty) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(24.0),
        child: CircularProgressIndicator(),
      ));
    }
    final items = List<Map<String, dynamic>>.from(data);
    items.sort((a,b){
      switch(mode){
        case MarketMode.gainers: return (b['change'] as num).compareTo(a['change'] as num);
        case MarketMode.losers: return (a['change'] as num).compareTo(b['change'] as num);
        case MarketMode.trending: return (b['volume'] as num).compareTo(a['volume'] as num);
        case MarketMode.favorites: return (b['fav'] as num).compareTo(a['fav'] as num);
      }
    });
    return ListView.separated(
      itemCount: items.length.clamp(0, 20),
      separatorBuilder: (_, __) => const Divider(height: 1, color: Color(0x22384B6A)),
      itemBuilder: (context, i) {
        final it = items[i];
        final up = (it['change'] as num) >= 0;
        return ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF141824),
            child: Text(it['symbol'][0], style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          title: Text('${it['name']} • ${it['symbol']}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          subtitle: Sparkline(values: List<double>.from(it['sparkline'].map<double>((e)=> (e as num).toDouble()))),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('\$${(it['price'] as num).toStringAsFixed(2)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('${up?'+':''}${(it['change'] as num).toStringAsFixed(2)}%',
                style: TextStyle(color: up? Colors.greenAccent : Colors.redAccent, fontWeight: FontWeight.w600)),
            ],
          ),
        );
      },
    );
  }
}

class Sparkline extends StatelessWidget {
  final List<double> values;
  const Sparkline({super.key, required this.values});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 22,
      child: CustomPaint(
        painter: _SparklinePainter(values),
        size: const Size(double.infinity, 22),
      ),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  final List<double> v;
  _SparklinePainter(this.v);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = const Color(0xFFA9C1FF);
    if (v.isEmpty) return;
    final path = Path();
    final minV = v.reduce(min);
    final maxV = v.reduce(max);
    final span = (maxV - minV) == 0 ? 1 : (maxV - minV);
    for (var i = 0; i < v.length; i++) {
      final x = size.width * (i / (v.length - 1));
      final y = size.height - ((v[i] - minV) / span) * size.height;
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
