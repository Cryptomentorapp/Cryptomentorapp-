
import 'dart:convert';
import 'package:flutter/material.dart';

class SignalsScreen extends StatefulWidget {
  final bool isPro;
  final VoidCallback onUpgrade;
  const SignalsScreen({super.key, required this.isPro, required this.onUpgrade});

  @override
  State<SignalsScreen> createState() => _SignalsScreenState();
}

class _SignalsScreenState extends State<SignalsScreen> {
  List<dynamic> signals = [];

  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }

  Future<void> _load() async {
    final s = await DefaultAssetBundle.of(context).loadString('assets/data/signals.json');
    setState(() => signals = jsonDecode(s));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Signals')),
      body: widget.isPro ? _proView() : _lockedView(),
    );
  }

  Widget _lockedView() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_outline, size: 64),
        const SizedBox(height: 12),
        const Text('Unlock Pro Signals', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        const Text('Get entry, SL, TP1/2/3 and AI risk controls.', textAlign: TextAlign.center),
        const SizedBox(height: 16),
        ElevatedButton.icon(onPressed: widget.onUpgrade, icon: const Icon(Icons.workspace_premium_outlined), label: const Text('Upgrade to Pro (mock)'))
      ]),
    ),
  );

  Widget _proView() {
    if (signals.isEmpty) return const Center(child: CircularProgressIndicator());
    return ListView.separated(
      padding: const EdgeInsets.all(12), itemCount: signals.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final s = signals[i] as Map<String, dynamic>;
        final status = s['status'] as String;
        Color chipColor = status=='Late'? Colors.orangeAccent : status=='Invalid'? Colors.redAccent : Colors.greenAccent;
        return Container(
          decoration: BoxDecoration(color: const Color(0xFF11131A), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x2233CCFF))),
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('${s['pair']} • ${s['tf']}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              const Spacer(),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: chipColor.withOpacity(0.15), border: Border.all(color: chipColor.withOpacity(0.5)), borderRadius: BorderRadius.circular(12)),
                child: Text(status, style: TextStyle(color: chipColor, fontWeight: FontWeight.w700)),
              )
            ]),
            const SizedBox(height: 8),
            Text('Entry: ${s['entry'][0]} - ${s['entry'][1]}'),
            Text('SL: ${s['sl']} • TP1: ${s['tp'][0]} • TP2: ${s['tp'][1]} • TP3: ${s['tp'][2]}'),
            Text('RR: ${s['rr']}'),
          ]),
        );
      },
    );
  }
}
